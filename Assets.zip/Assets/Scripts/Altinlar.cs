﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class Altinlar : MonoBehaviour
{
    // Start is called before the first frame update
    float spinSpeed = 3f;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float angle = spinSpeed + Time.deltaTime;
        transform.Rotate(angle * Vector2.up, Space.World);
    }

    void FixedUpdate()
    {
        
    }
}
