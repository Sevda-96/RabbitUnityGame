﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Runtime.InteropServices;


public class OyunaGecis : MonoBehaviour
{
    
    public void DigerSahne()
    {
        
        {
            Application.LoadLevel("Sahne");
        }


        
    }
}
