﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Runtime.InteropServices;

public class Fail1 : MonoBehaviour
{
    
   

    public void Turngame(string name)
    {
        Application.LoadLevel("Sahne");
  
    }

    
  
}
