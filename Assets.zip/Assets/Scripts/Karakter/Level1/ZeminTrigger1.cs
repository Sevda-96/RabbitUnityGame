﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;
using System;


public class ZeminTrigger1 : MonoBehaviour
{
    // Start is called before the first frame update

    Level1 lv;

    void Start()
    {
        lv = transform.root.gameObject.GetComponent<Level1>();
    }

 
    void OnTriggerEnter2D()
    {
        lv.yerdemi = true;
    }

    void OnTriggerStay2D()
    {
        lv.yerdemi = true;
    }


    void OnTriggerExit2D()
    {
        lv.yerdemi = false;
    }
}
