﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Level2: MonoBehaviour
{
    // Start is called before the first frame update
    public float hiz, ziplamagucu, maxhiz;
    public bool yerdemi, ciftzipla;
    public Text Elmasayisi, AltinSayisi;
    public float timeLeft = 20.0f;
    public Text startText;
    public int skor, skor2;
    public AudioClip[] sesler;

    Rigidbody2D rb;
    Animator animator;


    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && yerdemi)
        {
            if (yerdemi)
            {
                rb.AddForce(Vector2.up * ziplamagucu);
                ciftzipla = true;
            }
            else
            {
                if (ciftzipla)
                {
                    ciftzipla = false;
                    rb.AddForce(Vector2.up * ziplamagucu);
                }



            }

        }
        timeLeft -= Time.deltaTime;
        startText.text = "Time:"+ (timeLeft).ToString("0");
        if (timeLeft < 0)
        {
            Application.LoadLevel("FailScene");
        }



    }
    void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal");
       
        rb.AddForce(Vector3.right * h * hiz);
        animator.SetFloat("Speed", Math.Abs(h));
        animator.SetBool("Yerde", yerdemi);


        if (h > 0.1f)
        {
            transform.localScale = new Vector2(1, 1);

        }
        if (h < -0.1f)
        {
            transform.localScale = new Vector2(-1, 1);

        }


        if (rb.velocity.x > maxhiz)
        {
            rb.velocity = new Vector2(maxhiz, rb.velocity.y);
        }

        if (rb.velocity.x < -maxhiz)
        {
            rb.velocity = new Vector2(-maxhiz, rb.velocity.y);
        }
    }

    void olme()
    {
        Application.LoadLevel("FailScene");

    }
    void OnCollisionEnter2D(Collision2D nesne)
    {
        if (nesne.gameObject.tag == "Tuzak")
        {
            GetComponent<AudioSource>().PlayOneShot(sesler[2]);
            GetComponent<SpriteRenderer>().color = Color.red;
            rb.AddForce(Vector2.up * ziplamagucu);
            olme();
      
        }
    }

    public void OnTriggerEnter2D(Collider2D nesne)
    {
        if (nesne.gameObject.tag == "Elma")
        {

            skor++;
            GetComponent<AudioSource>().PlayOneShot(sesler[0]);
            Elmasayisi.text = skor.ToString();
            Destroy(nesne.gameObject);

        }
        if (nesne.gameObject.tag == "Altin")
        {
            skor2++;
            GetComponent<AudioSource>().PlayOneShot(sesler[1]);
            AltinSayisi.text = skor.ToString();
            Destroy(nesne.gameObject);
        }

        if (nesne.gameObject.tag == "Tuzak")
        {

            GetComponent<AudioSource>().PlayOneShot(sesler[2]);

        }

        if (nesne.gameObject.tag == "Kapi")
        {
          
              Application.LoadLevel("Sahne2");
        }



    }



}
