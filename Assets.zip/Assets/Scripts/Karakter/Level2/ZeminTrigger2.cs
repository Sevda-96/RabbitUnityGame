﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;
using System;


public class ZeminTrigger2 : MonoBehaviour
{
    // Start is called before the first frame update

    Level2 kr;

    void Start()
    {
        kr = transform.root.gameObject.GetComponent<Level2>();
    }

    // Update is called once per frame
    void Update()
    {

    }
    void OnTriggerEnter2D()
    {
        kr.yerdemi = true;
    }

    void OnTriggerStay2D()
    {
        kr.yerdemi = true;
    }


    void OnTriggerExit2D()
    {
        kr.yerdemi = false;
    }
}
