﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZeminTrigger3 : MonoBehaviour
{
    Level3 lv;

    void Start()
    {
        lv = transform.root.gameObject.GetComponent<Level3>();
    }


    void OnTriggerEnter2D()
    {
        lv.yerdemi = true;
    }

    void OnTriggerStay2D()
    {
        lv.yerdemi = true;
    }


    void OnTriggerExit2D()
    {
        lv.yerdemi = false;
    }
}
