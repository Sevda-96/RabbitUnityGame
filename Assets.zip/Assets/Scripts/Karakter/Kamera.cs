﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Security.Cryptography;
using UnityEngine;

public class Kamera : MonoBehaviour
{
    // Start is called before the first frame update

    public Transform karakter;
    void Start()
    {
        karakter = GameObject.FindGameObjectWithTag("Player").transform;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = new Vector3(karakter.position.x, karakter.position.y, -10);
    }
}
